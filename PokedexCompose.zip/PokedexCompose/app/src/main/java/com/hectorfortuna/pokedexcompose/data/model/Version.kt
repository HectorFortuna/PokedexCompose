package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class Version(
    val name: String,
    val url: String
)