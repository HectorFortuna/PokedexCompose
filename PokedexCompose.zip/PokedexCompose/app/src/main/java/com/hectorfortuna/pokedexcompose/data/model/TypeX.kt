package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class TypeX(
    val name: String,
    val url: String
)