package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class GenerationViii(
    val icons: IconsX
)