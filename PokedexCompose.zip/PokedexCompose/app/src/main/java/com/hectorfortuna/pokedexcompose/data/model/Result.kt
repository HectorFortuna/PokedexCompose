package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class Result(
    val name: String,
    val url: String
)