package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class Type(
    val slot: Int,
    val type: TypeX
)