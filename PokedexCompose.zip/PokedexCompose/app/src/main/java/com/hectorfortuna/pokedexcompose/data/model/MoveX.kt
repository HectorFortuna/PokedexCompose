package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class MoveX(
    val name: String,
    val url: String
)