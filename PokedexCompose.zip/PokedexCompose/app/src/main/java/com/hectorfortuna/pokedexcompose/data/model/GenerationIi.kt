package com.hectorfortuna.pokedexcompose.data.model

import com.google.gson.annotations.SerializedName

data class GenerationIi(
    val crystal: Crystal,
    val gold: Gold,
    val silver: Silver
)